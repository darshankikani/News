<?php
class Query extends CI_model{
	public function fetch_cat($l){
	$this->db->select('c_id,c_name');
  	$this->db->from('category');
  	$this->db->where('l_id',$l);
  	$query=$this->db->get();
  	header('Content-Type: application/json');
    return json_encode($query->result());
	}

	public function fetch_news($l,$u,$c){
	
  $this->db->select('t1.n_id,t1.u_id,t1.headline,t1.description,t3.v_id,t3.url,t4.b_id,t2.i_id,t2.url_i,t1.n_g_id');

  	$this->db->from('newsd as t1');
  	$this->db->where('t1.l_id',$l);
  		$this->db->where('t1.u_id',$u);
  			$this->db->where('t1.c_g_id',$c);
        //$this->db->distinct();
        $this->db->join('video as t3','t1.n_g_id=t3.n_g_id','LEFT');
        $this->db->join('bookmark as t4','t1.n_g_id=t4.n_g_id','LEFT');
        $this->db->join('image as t2','t1.n_g_id=t2.n_g_id','right outer');
        //$this->db->order_by('t3.n_g_id');
  	$query=$this->db->get();

  	header('Content-Type: application/json');
    return json_encode($query->result());
	}

	public function fetch_user($u){
	$this->db->select('*');
  	$this->db->from('user');
  	$this->db->where('u_id',$u);
  	$query=$this->db->get();
  	header('Content-Type: application/json');
    return json_encode($query->result());
	}

}
?>