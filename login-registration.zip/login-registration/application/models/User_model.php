<?php
class User_model extends CI_model{
    public function new_register_user(){
        $username=$this->input->post('u_name');
        $mobilenumber=$this->input->post('mo_no');
        $email=$this->input->post('email');
        $password=$this->input->post('password');
        $data = array(
              'u_name ' => $username,
              'mo_no' => $mobilenumber,
              'email' => $email,
              'password' => $password
         );
        $this->db->insert('user',$data);
        return $data;
    }

    public function login_user($email,$pass){
      $this->db->select('*');
      $this->db->from('user');
      $this->db->where('email',$email);
      $this->db->where('password',$pass);
      if($query=$this->db->get()){
          return $query->row_array();
      }
      else{
        return false;
      }
    }

   public function fetch_news(){
      $this->db->select('*');
      $this->db->from('newsd');
      $this->db->where('status',1);
      $query=$this->db->get();
      if($query->num_rows()>0){
        return $query->result();
      }else{
        return false;
      }
    }

    public function fetch_news1(){
      $r=($this->input->post('range')/100000);
      //$r=$this->input->post('range');
      $lat=$this->input->post('latitude');
      $lon=$this->input->post('longitude');
      $this->db->select('*');
      $this->db->from('newsd');
      $this->db->where('status',1);
      $query=$this->db->get();
      $b= array(""=>"");
      foreach ($query->result() as $key) {
        $a = (array)($key);

        if(($a['latitude'] < $lat+$r)&&($a['latitude'] > $lat-$r)){
          if(($a['longitude'] < $lon+$r)&&($a['longitude'] > $lon-$r)){
           array_push($b,$a);
          }
        }
          //echo $a['latitude'];
          //echo $a['longitude'];
       // echo sqrt(pow($a['latitude']-$lat,2)+pow($a['longitude']-$lon,2))."ghg";
        /*if((pow($a['latitude']-$lat,2)+pow($a['longitude']-$lon,2))<(pow($r,2))){
          array_push($b,$a);
        }*/
      };
      header('Content-Type: application/json');
        return json_encode($b);
    }

    public function change_p(){
       $o=$this->input->post('opassword');
        $n=$this->input->post('npassword');
        $n1=$this->input->post('npassword1');
      $this->db->select('password');
      $this->db->from('user');
      $this->db->where('u_id',$_SESSION['u_id']);
      $query=$this->db->get();
      $d=(array)($query->result()[0]);
       if($query->num_rows()>0){
        if($d['password']==$o){

          $this->db->set('password',$n);
           $this->db->where('u_id',$_SESSION['u_id']);
          return $this->db->update('user');
        }
      }else{
        return false;
      }
    }

    public function fetch_history(){
      $this->db->select_min('n_id');
      $this->db->select('headline,description,l_id,u_id,latitude,longitude,date,status,n_g_id,c_g_id');
      $this->db->from('newsd');
      $this->db->where('u_id',$_SESSION['u_id']);
      $this->db->group_by("n_g_id", "asc");
      $query=$this->db->get();
      if($query->num_rows()>0){
        return $query->result();
      }else{
        return false;
      }
    }

    public function bookmark($n_g_id){  
        $data = array(
              'u_id ' => $_SESSION['u_id'],
              'n_g_id' => $n_g_id
         );
       return $this->db->insert('bookmark',$data);
    }

     public function bookmark_d($n_g_id){  
        $data = array(
              'u_id ' => $_SESSION['u_id'],
              'n_g_id' => $n_g_id
         );
       return $this->db->delete('bookmark',$data);
    }

    public function fetch_book(){
      $this->db->select('t1.u_id,t1.n_g_id,t2.n_g_id,t2.headline,t2.description');
      $this->db->from('bookmark as t1');
      $this->db->where('t1.u_id',$_SESSION['u_id']);
       $this->db->join('newsd as t2','t2.n_g_id=t1.n_g_id','LEFT') ;
      $query=$this->db->get();
      $query->num_rows();
      if($query->num_rows()>0){
        return $query->result();
      }else{
        return false;
      }
    }

    public function fetch_news_admin(){
      $this->db->select('t1.n_id,t1.l_id,t1.u_id,t1.headline,t1.description,t2.i_id,t2.url_i,t3.v_id,t3.url');
        $this->db->from('newsd as t1');
        $this->db->where('status',0);
            $this->db->join('image as t2','t1.n_g_id=t2.n_g_id','LEFT');
            $this->db->join('video as t3','t1.n_g_id=t3.n_g_id','LEFT');
        $query=$this->db->get();
      if($query->num_rows()>0){
        return $query->result();
      }else{
        return false;
      }
    }

    public function fetch_news_admin1(){
      $this->db->select('t1.n_id,t1.l_id,t1.u_id,t1.headline,t1.description,t2.i_id,t2.url_i,t3.v_id,t3.url');
        $this->db->from('newsd as t1');
        $this->db->where('status',1);
            $this->db->join('image as t2','t1.n_g_id=t2.n_g_id','LEFT');
            $this->db->join('video as t3','t1.n_g_id=t3.n_g_id','LEFT');
        $query=$this->db->get();
      if($query->num_rows()>0){
        return $query->result();
      }else{
        return false;
      }
    }

    public function status_c($id){
      //echo $id;
      $this->db->set('status',1);
      $this->db->where('n_id',$id);
      return $this->db->update('newsd');

    }

    public function deleteuser($id){
          $this->db->where('newsd.n_id', $id);
          return $this->db->delete('newsd');
    }

    public function new_news_register(){
        $lang=$this->input->post('lang');
        $cat=$this->input->post('cat');
        $headline=$this->input->post('headline');
        $description=$this->input->post('description');
        //$image=$this->input->post('imagefile[]');
       // $video=$this->input->post('videofile');
        $data = array(
              'l_id' => $lang,
              'u_id' => $_SESSION['u_id'],
              'latitude' => $_SESSION['latitude'],
              'longitude' => $_SESSION['longitude'],
              'c_g_id' => $cat,
              'headline' => $headline,
              'description' => $description
         );
        $this->db->insert('newsd',$data);
        $new_id=$this->db->insert_id();
        $this->db->set('n_g_id',$new_id);
        $this->db->where('n_id',$new_id);
        $this->db->update('newsd');
        //return $data;
       // return $this->new_url_image($new_id);
        //return $video;
        return $new_id;
    }

    public function new_url_image($image= array(),$new_id){
      foreach($image as $i=>$v){
       // $im['url_i'] = $image[$i]['imagefile'];
        $im = array('n_g_id' => $new_id,
                     'url_i' => $image[$i]['imagefile']);
      $this->db->insert('image', $im);
     // $this->db->insert('image',$im2);
      }
    }

    public function comment_v($n_g_id){
      $this->db->select('*');
      $this->db->from('comment');
      $this->db->where('n_g_id',$n_g_id);
      $query=$this->db->get();
        return $query->result();
    }

    public function new_url_video($video,$new_id){
      $vm = array('url'=> $video,
                  'n_g_id'=>$new_id);
      $this->db->insert('video', $vm);
    }

    public function tr_news($n_id){
      $this->db->select('*');
      $this->db->from('newsd');
      $this->db->where('n_id',$n_id);
      $query=$this->db->get();
        return $query->result();
    }

    public function new_trans_news(){
        $langa=$this->input->post('lang');
        $cat=$this->input->post('catgid');
        $headline=$this->input->post('headline');
        $description=$this->input->post('description');
        $latitude=$this->input->post('latitude');
        $longitude=$this->input->post('longitude');
        $ngid=$this->input->post('newsgid');
        $userid=$this->input->post('userid');
        $data = array(
              'l_id' => $langa,
              'u_id' => $userid,
              'latitude' => $latitude,
              'longitude' => $longitude,
              'c_g_id' => $cat,
              'headline' => $headline,
              'description' => $description,
              'status' => 1,
              'n_g_id' => $ngid
         );
        $this->db->insert('newsd',$data);
        //$this->db->insert_id();
        return $data;

    }

    public function comment_in(){
      $text=$this->input->post('commenttext');
      $ngid=$this->input->post('ngid');
        $data = array(
              'u_id' => $_SESSION['u_id'],
              'text' => $text,
              'n_g_id' => $ngid
         );
        $this->db->insert('comment',$data);
        return $data;
    }
  }
?>
