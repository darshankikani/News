<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login-CI Login </title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" media="screen" title="no title">
  </head>
  <body>
    <div class="container" style="margin-top: 150px;">
    <div class="row">
        <div class="col-md-4 col-md-offset-4" style="box-shadow: 5px 5px 10px 1px grey; background: white;">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Login</h3>
                </div>
                <?php
              $success_msg= $this->session->flashdata('success_msg');
              $error_msg= $this->session->flashdata('error_msg');

                  if($success_msg){
                    ?>
                    <div class="alert alert-success">
                      <?php echo $success_msg; ?>
                    </div>
                  <?php
                  }
                  if($error_msg){
                    ?>
                    <div class="alert alert-danger">
                      <?php echo $error_msg; ?>
                    </div>
                    <?php
                  }
                  ?>
                <div class="panel-body">
                    <form role="form" method="post" action="<?php echo base_url('user/login_user'); ?>">
                        <fieldset>
                            <div class="form-group"  >
                                <input class="form-control" placeholder="E-mail" name="email" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" autofocus required>
                            </div>
                            <div class="form-group">
                                <input class="form-control" id="n" placeholder="Password" name="password" type="password"  required>      
                            <input type="checkbox" onclick="myFunction()">Show Password
                                  <script type="text/javascript">
                                    function myFunction() {
                                       var x = document.getElementById("n");
                                      if (x.type === "password") {
                                         x.type = "text";
                                      } else {
                                          x.type = "password";
                                    }
                                  } 
                                </script>
                            </div>
                            <input type="checkbox" onclick="getLocation()" required>Get Access to my location</input>
                            <input type="hidden" name="cod" id="cod"/>
          <script>
         var x = document.getElementById("cod");
         function getLocation() {
         if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(showPosition);
         } else { 
             x.innerHTML = "Geolocation is not supported by this browser.";
            }
         }
         function showPosition(position) {
          var lx=position.coords.latitude;
            var ly=position.coords.longitude;
        // x.innerHTML="lattitude "+lx+"</br>"+" longitude "+ly;
        var l=""+lx+","+ly;
        document.getElementById("cod").value=l;  
         }
         </script>
                                <input class="btn btn-lg btn-success btn-block" type="submit" value="login" name="login" >
                        </fieldset>
                    </form>
                    <center><hr width=70%></center>
                    <form role="form1" method="post" action="<?php echo base_url('user/register_user'); ?>">
                      <fieldset>
                      <input class="btn btn-lg btn-success btn-block" type="submit" value="Register" id="r" >
                        </fieldset>
                      </form>
                </div>
            </div>
        </div>
    </div>
</div>
  </body>
</html>
