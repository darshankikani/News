<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Translate</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  </head>
  <body onload="mycat()">
<div class="container">
  <div class="row">
    <div class="col-md-4">
      <table class="table table-bordered table-striped">
      	<tr>
          <th colspan="2"><h4 class="text-center">News</h3></th>
        </tr>
      	<tr>
      		<td>Headline</td>
      		<td>Description</td>
      	</tr>
      	<?php foreach ($posts as $post) {?>
      		<tr>
      		<td><?php echo $post->headline;?></td>
      		<td><?php echo $post->description;?></td>
            <?php $l=$post->l_id;
             $n=$post->n_g_id;
             $u=$post->u_id;
             $lat=$post->latitude;
             $lon=$post->longitude;
             $c=$post->c_g_id;
             ?>
      		</tr>
      	<?php }?>
      </table>

    </div>
  </div>
 <form action = "<?php echo base_url('upload/trans_news'); ?>" method = "post">
         Choose Translation Language
         <br/>
         <script type="text/javascript">
            function mycat(){
               var x= '<?php echo $l?>';
               if(x==1){
                  document.getElementById('e').style.display="inline";
                  document.getElementById('g').style.display="none";
                  document.getElementById('h').style.display="none";
               }
               else if(x==2){
                  document.getElementById('h').style.display="inline";
                  document.getElementById('e').style.display="none";
                  document.getElementById('g').style.display="none";
               }
               else{
                 document.getElementById('g').style.display="inline";
                 document.getElementById('e').style.display="none";
                 document.getElementById('h').style.display="none";
               }
            }
         </script>
         <div id="e" style="display: none" >
          <input type="radio" name="lang" value="2" checked> हिंदी<br>
          <input type="radio" name="lang" value="3"> ગુજરાતી<br>
         </div>

         <div id="h" style="display: none">
        <input type="radio" name="lang" value="1" checked>English<br>
          <input type="radio" name="lang" value="3"> ગુજરાતી<br>
         </div>
         
         <div id="g" style="display: none">
          <input type="radio" name="lang" value="1" checked> English<br>
          <input type="radio" name="lang" value="2"> हिंदी<br>
         </div>
         
         <br/><br/>
         <input type="hidden" name="newsgid" value="<?php echo $n?>"/>
          <input type="hidden" name="userid" value="<?php echo $u?>"/>
           <input type="hidden" name="catgid" value="<?php echo $c?>"/>
            <input type="hidden" name="latitude" value="<?php echo $lat?>"/>
             <input type="hidden" name="longitude" value="<?php echo $lon?>"/>
         Headline
         <br/>
         <input type = "text" name = "headline" size = "20" required />
         <br/> <br/>
         Description<br/>
         <textarea name="description" rows="10" cols="50" required></textarea>
         <br/><br/>
         <input type = "submit" value = "Submit" /> 
      </form>

<a href="<?php echo base_url('user/user_logout');?>" >  <button type="button" class="btn-primary">Logout</button></a>
</div>

  </body>
</html>