<?php 
    echo form_open_multipart('upload/do_upload_video');
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Video Upload</title>
 </head>
 <body>
 	      <?php  $posts;?>
 		<form  method = "post">
 			Upload Video<br/>
         <input type="file" name="videofile" size="20"/><br/>
         <input type="submit" name="Upload" value="Next"/><br/></form>
         <a href="<?php echo base_url('upload/a_image');?>"><button>Cancel</button></a>
 </body>
 </html>




