<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>change Password</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" media="screen" title="no title">
  </head>
  <body>
    <div class="container" style="margin-top: 150px;">
    <div class="row">
        <div class="col-md-4 col-md-offset-4" style="box-shadow: 5px 5px 10px 1px grey; background: white;">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Login</h3>
                </div>
                <div class="panel-body">
                    <form role="form" method="post" action="<?php echo base_url('user/change_pass'); ?>">
                      <div class="form-group">
                                  <input class="form-control" id="m" placeholder="Old Password" name="opassword" type="password"  required>
                              </div>
                            <div class="form-group">
                                  <input class="form-control" id="m" placeholder="New Password" name="npassword" type="password"  required>
                              </div>
                              <div class="form-group">
                                  <input class="form-control" id="m1" placeholder="Confirm Password" name="npassword1" type="password" onblur="myFunction()" required>
                                  <script type="text/javascript">
                                    function myFunction() {
                                       var x = document.getElementById("m").value;
                                       var y = document.getElementById("m1").value;
                                      if (x !== y) {
                                         document.getElementById("m2").innerHTML="Password does not match";
                                      }
                                      else{
                                          document.getElementById("m2").style.visibility="hidden";
                                      }
                                  } 
                                  </script>
                            </div>
                                <input class="btn btn-lg btn-success btn-block" type="submit" value="save password">
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
  </body>
</html>
