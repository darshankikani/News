<html>
   <head> 
      <title>Upload Form</title> 
   </head>
   <body> 
      <form action = "<?php echo base_url('upload/new_news'); ?>" method = "post" enctype="multipart/form-data">
         Choose Your Language

         <select name="lang" id="l" onchange="mycat()" required>
         <option value="None"></option>
         <option value="1">English</option>
         <option value="2">हिंदी</option>
         <option value="3">ગુજરાતી</option>
         </select>
         
         <br/><br/>
         <div id="d"></div>
         Choose News Category
         <script type="text/javascript">
            function mycat(){
               var x=document.getElementById('l').value;
               if(x==1){
                  document.getElementById('e').style.display="inline";
                  document.getElementById('g').style.display="none";
                  document.getElementById('h').style.display="none";
               }
               else if(x==2){
                  document.getElementById('h').style.display="inline";
                  document.getElementById('e').style.display="none";
                  document.getElementById('g').style.display="none";
               }
               else{
                 document.getElementById('g').style.display="inline";
                 document.getElementById('e').style.display="none";
                 document.getElementById('h').style.display="none";
               }
            }
         </script>
         <div id="e" style="display: none">
         <select name="cat" required>
         <option value="1">Sports</option>
         <option value="2">Crime</option>
         <option value="3">Entertainment</option>
         </select>
         </div>

         <div id="h" style="display: none">
         <select name="cat" required>
         <option value="1">खेल</option>
         <option value="2">अपराध</option>
         <option value="3">मनोरंजन</option>
         </select>
         </div>
         
         <div id="g" style="display: none">
         <select name="cat" required>
         <option value="1">રમતો</option>
         <option value="2">અપરાધ</option>
         <option value="3">મનોરંજન</option>
         </select>
         </div>
         <br/><br/>
         Headline
         <br/>
         <input type = "text" name = "headline" size = "20" required />
         <br/> <br/>
         Description<br/>
         <textarea name="description" rows="10" cols="50" required></textarea>
         <br/><br/>
         Upload Image<br/>
         <input type="file" name="imagefile[]"  multiple="multiple" /><br/><br/>
         Upload Video<br/>
         <input type="file" name="videofile" size="20"/><br/>
         <br />
         <input type = "submit" value = "Submit" /> &nbsp;&nbsp;&nbsp;
<a href="<?php echo base_url('user/user_profile');?>" >  <button type="button" class="btn-primary">Back</button></a>
      </form>
        </body>
</html>