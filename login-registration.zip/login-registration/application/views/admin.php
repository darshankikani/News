<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Admin</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  </head>
  <body>
<div class="container">
  <div class="row">
    <div class="col-md-4">
      <table class="table table-bordered table-striped">
      	<tr>
          <th colspan="2"><h4 class="text-center">News</h3></th>
        </tr>
      	<tr>
          <td>News_id</td>
          <td>User_id</td>
      		<td>Headline</td>
      		<td>Description</td>
          <td>Image_id</td>
          <td>Image_Url</td>
          <td>Video_id</td>
          <td>Video_Url</td>
      	</tr>
      	<?php foreach ($posts as $post) {?>
      		<tr>
          <td><?php echo $post->n_id;?></td>
          <td><?php echo $post->u_id;?></td>
      		<td><?php echo $post->headline;?></td>
      		<td><?php echo $post->description;?></td>
          <td><?php echo $post->i_id;?></td>
          <td><?php echo $post->url_i;?></td>
          <td><?php echo $post->v_id;?></td>
          <td><?php echo $post->url;?></td>
          <td><a href="<?php echo base_url(); ?>index.php/user/edit/<?php echo $post->n_id; ?>" class="btn btn-success">Approve</a>|| <a href="<?php echo base_url(); ?>index.php/user/delete/<?php echo $post->n_id; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a></td>
      		</tr>
      	<?php }?>

      </table>
    </div>
  </div>
<a href="<?php echo base_url('user/user_logout');?>" >  <button type="button" class="btn-primary">Logout</button></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="<?php echo base_url('user/approved_news');?>" >  <button type="button" class="btn-primary">Approved News</button></a>
</div>
  </body>
</html>