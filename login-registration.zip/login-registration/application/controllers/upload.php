<?php
  
   class Upload extends CI_Controller {
	
      public function __construct() { 
         parent::__construct(); 
         $this->load->helper(array('form', 'url')); 
      }
		
      public function index() { 
         $this->load->view('upload_form', array('error' => ' ' )); 
      } 
		
      public function new_news(){
         $this->load->model('user_model');
        $new_id= $this->user_model->new_news_register();
        $a=$_FILES['imagefile'];
        $ImageCount = count($a['name']);
         for($i = 0; $i < $ImageCount; $i++){
            $_FILES['file']['name']       = $a['name'][$i];
            $_FILES['file']['type']       = $a['type'][$i];
            $_FILES['file']['tmp_name']   = $a['tmp_name'][$i];
            $_FILES['file']['error']      = $a['error'][$i];
            $_FILES['file']['size']       = $a['size'][$i];

         $config['upload_path']   = 'application/uploads/'; 
         $config['allowed_types'] = 'gif|jpg|png'; 
         $config['max_size']      = 1000; 
         $config['max_width']     = 1024; 
         $config['max_height']    = 1024;  
         $this->load->library('upload', $config);
        // $this->upload->initialize($config);
         if ( $this->upload->do_upload('file')) {
            $imageData = $this->upload->data(); 
             $uploadImgData[$i]['imagefile'] = $imageData['file_name'];

         }
        }   
      if(!empty($uploadImgData)){
         $this->load->model('user_model');
          $this->user_model->new_url_image($uploadImgData,$new_id);
         // $this->load->view('user_profile');
      
      } 

        $config1['upload_path']   = 'application/uploads/video'; 
         //$config['allowed_types'] = 'mp4'; 
         $config1['max_size']      = '1024000000000'; 
         $config1['allowed_types'] = '*';
         $config1['overwrite'] = FALSE;
         $config1['remove_spaces'] = TRUE;
         //echo $new_id;
         $this->load->library('upload', $config1);
         $this->upload->initialize($config1);
         if ( ! $this->upload->do_upload('videofile')) {
           $error = array('error' => $this->upload->display_errors()); 
            //$this->load->view('up_video'); 
            $this->load->view('user_profile.php'); 
         }
         else { 
            $data = array('upload_data_video' => $this->upload->data()); 
            $this->load->model('user_model');
            $this->user_model->new_url_video($data['upload_data_video']['file_name'],$new_id);
           // $this->user_model->video_ng_id($new_id);
            $this->load->view('user_profile.php'); 
         } 
      }

      public function trans_news(){
        $this->load->model('user_model');
        $this->user_model->new_trans_news();
      }

      
   } 
?>





  

           