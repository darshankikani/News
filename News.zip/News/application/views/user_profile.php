<?php
$user_id=$this->session->userdata('email');
if(!$user_id){

  redirect('user/login_view');
}
 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login-CI Login </title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" media="screen" title="no title">
  </head>
  <body style="margin-top: 200px">
            <form role="form" method="post" action="<?php echo base_url('upload/index'); ?>">
                      <fieldset>
                      <center><input class="btn btn-lg btn-success btn-block" style=" width: 300px;" type="submit" value="Upload News" id="r" >
                        </fieldset>
            </form><br/>
            <form role="form1" method="post" action="<?php echo base_url('user/view_news'); ?>">
                      <fieldset>
                      <center><input class="btn btn-lg btn-success btn-block" style=" width: 300px;" type="submit" value="View News" id="r" ></center>
                        </fieldset>
            </form><br/>
            <form role="form1" method="post" action="<?php echo base_url('user/view_history'); ?>">
                      <fieldset>
                      <center><input class="btn btn-lg btn-success btn-block" style=" width: 300px;" type="submit" value="View History" id="r" ></center>
                        </fieldset>
            </form><br/>
             <form role="form1" method="post" action="<?php echo base_url('user/bookmark_news'); ?>">
                      <fieldset>
                      <center><input class="btn btn-lg btn-success btn-block" style=" width: 300px;" type="submit" value="Bookmark" id="r" ></center>
                        </fieldset>
            </form><br/>
            <form role="form2" method="post" action="<?php echo base_url('user/register1'); ?>">
                      <fieldset>
                      <center><input class="btn btn-lg btn-success btn-block" style=" width: 300px;" type="submit" value="User Profile" id="r" ></center>
                        </fieldset>
            </form><br/>
            <form role="form3" method="post">
                      <fieldset>
                      <center>  <a href="<?php echo base_url('user/user_logout');?>" >  <button type="button" class="btn btn-lg btn-success btn-block" style=" width: 300px;">Logout</button></a>
                        </fieldset></center>
            </form>
</body>
</html>



