<?php 
    echo form_open_multipart('upload/do_upload');
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Image Upload</title>
 </head>
 <body>
 		<form  method = "post">
 			Upload Image<br/>
         <input type="file" name="imagefile[]"  multiple="multiple" /><br/><br/>
         <input type="submit" name="Upload" value="Upload"/></form>
        <a href="<?php echo base_url('user/user_profile');?>"><button>Cancel</button></a>
 </body>
 </html>




