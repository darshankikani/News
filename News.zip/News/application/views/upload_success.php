<html>
   <head> 
      <title>Upload Form</title> 
   </head>
   <body>  
      <h3>Your file was successfully uploaded!</h3>  
      <ul> 
       <!--  <?php foreach ($upload_data as $item => $value):?> 
         <li><?php echo $item;?>: <?php echo $value;?></li> 
         <?php endforeach;
        // $this->load->base_url('upload/u_url/$upload_data["full_path"]');
         //echo $upload_data['full_path'];
          ?>-->
      </ul>  
      <p><?php echo anchor('upload/a_image ', 'Upload Another File!'); ?></p>  
      <a href="<?php echo base_url('user/user_profile');?>"><button>Cancel</button></a>
   </body>
	
</html>