
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>User Profile Dashboard-CodeIgniter Login Registration</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  </head>
  <body>
<div class="container">
  <div class="row">
    <div class="col-md-4">
      <table class="table table-bordered table-striped">
      	<tr>
          <th colspan="2"><h4 class="text-center">News</h3></th>
        </tr>
      	<tr>
      		<td>Headline</td>
      		<td>Description</td>
      	</tr>
      	<?php foreach ($posts as $post) {?>
      		<tr>
      		<td><?php echo $post->headline;?></td>
      		<td><?php echo $post->description;?></td>
          <td><a href="<?php echo base_url(); ?>index.php/user/bookmark_delete/<?php echo $post->n_g_id;?>" class="btn btn-success">UnBookmark</a></td>
      		</tr>
      	<?php }?>
      </table>
    </div>
  </div>
<a href="<?php echo base_url('user/user_logout');?>" >  <button type="button" class="btn-primary">Logout</button></a>&nbsp;&nbsp;&nbsp;
<a href="<?php echo base_url('user/user_profile');?>" >  <button type="button" class="btn-primary">Back</button></a>
</div>
  </body>
</html>
