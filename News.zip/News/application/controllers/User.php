<?php

class User extends CI_Controller {

    public function __construct(){
            parent::__construct();
      			$this->load->helper('url');
      	 		$this->load->model('user_model');
            $this->load->library('session');
    }

    public function index(){
    $this->load->view("login.php");
    }

     function register_user(){
    $this->load->view('Register.php');
    }   

    function register1(){
      $this->load->view('Register2.php'); 
    }

    function new_value() {

         $result=$this->input->post('email');
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('email',$result);
        $query=$this->db->get();
        if($query->num_rows()>0){
          $this->load->view('register');
          echo "User Already Exist!!!";
        }else{
          $data=$this->user_model->new_register_user();
          // header('Content-Type: application/json');
          //  echo json_encode($data);
          $this->load->view('login');
        }      
    }

    public function login_view(){
    $this->load->view("login.php");
    }

    function login_user(){
      $user_login=array(
      'email'=>$this->input->post('email'),
      'password'=>$this->input->post('password')
        );
        $l=$this->input->post('cod');
        $c=explode(',',$l ,2);
        $c1=substr($l, (strpos($l, ',')?: -1)+1);
        $data=$this->user_model->login_user($user_login['email'],$user_login['password']);
          if($data)
          {
           $this->session->set_userdata('u_id',$data['u_id']);
            $this->session->set_userdata('u_name',$data['u_name']);
            $this->session->set_userdata('mo_no',$data['mo_no']);
            $this->session->set_userdata('email',$data['email']);
            $this->session->set_userdata('latitude',$c[0]);
            $this->session->set_userdata('longitude',$c1);
            //header('Content-Type: application/json');
            //echo json_encode($data);
            if($user_login['email']=='xyz@admin.com' && $user_login['password']==1234){
              $this->load->model('user_model');
              $this->data['posts'] = $this->user_model->fetch_news_admin();
              $this->load->view('admin.php',$this->data);
            }else{
           $this->load->view('user_profile.php');
           // $this->load->view();
           }
          }
          else{
            $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
            $this->load->view("login.php");
          }
    }

    public function edit($n_id){
     $a=$this->user_model->status_c($n_id);
    // $this->load->model('user_model');
     if($a){
      $this->load->model('user_model');
      $this->data['posts'] = $this->user_model->fetch_news_admin();
      $this->load->view('admin.php',$this->data);
      }
  }

    public function delete($n_id){
    $query = $this->user_model->deleteuser($n_id);

    if($query){
      //header('location:'.base_url().$this->index());
      $this->load->model('user_model');
      $this->data['posts'] = $this->user_model->fetch_news_admin();
      $this->load->view('admin.php',$this->data);
      //$this->load->view('admin.php');
    }
  }

    function user_profile(){
    $this->load->view('user_profile.php');
    }

    public function bookmark_edit($n_g_id){
      $b=$this->user_model->bookmark($n_g_id); 
      //$this->view_news();
    }

    public function bookmark_delete($n_g_id){
      $c=$this->user_model->bookmark_d($n_g_id); 
      $this->bookmark_news(); 
    }

    public function bookmark_news(){
        $this->data['posts'] = $this->user_model->fetch_book(); 
         //header('Content-Type: application/json');
           // echo json_encode($this->data['posts']);
          $this->load->view('book_news',$this->data);

    }

     public function view_history(){
       // $this->load->model('user_model');
        $this->data['posts'] = $this->user_model->fetch_history();
        //$this->load->view('show_news',$this->data);
        header('Content-Type: application/json');
           echo json_encode($this->data['posts']);
    }

    public function view_news(){
        $this->load->model('user_model');
        $this->data['posts'] = $this->user_model->fetch_news();
        $this->load->view('show_news',$this->data);
    }

     public function view_news1(){
        $this->load->model('user_model');
        $data= $this->user_model->fetch_news1();
        //$this->load->view('show_news1',$this->data);
        print_r( $data);
    }

    public function change_pass(){
      $this->load->model('user_model');
        $this->data['posts'] = $this->user_model->change_p();
         header('Content-Type: application/json');
           echo json_encode($this->data['posts']);
    }
    
    public function c_password(){
        $this->load->view('change_p');
        
    }

    public function user_logout(){
      $this->session->sess_destroy();
      redirect('user/login_view', 'refresh');
    }

    public function comment(){
      $this->load->model('user_model');
      $data=$this->user_model->comment_in();
      header('Content-Type: application/json');
            echo json_encode($data);
    }

     public function v_comment($n_g_id){
      $this->load->model('user_model');
      $data=$this->user_model->comment_v($n_g_id);
      header('Content-Type: application/json');
         echo json_encode($data);
    }

    public function approved_news(){
      $this->load->model('user_model');
      $this->data['posts'] = $this->user_model->fetch_news_admin1();
      $this->load->view('admin1.php',$this->data);
    }

    public function translate($n_id){
     // echo "translate".$n_id;
      $this->load->model('user_model');
       $this->data['posts'] =$this->user_model->tr_news($n_id);
      $this->load->view('translate.php',$this->data);

    }
    
}


