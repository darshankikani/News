<?php
class General extends CI_Controller {

    public function __construct(){
            parent::__construct();
            $this->load->database();
            $this->load->helper('url');
            $this->load->library('session');
    }

    public function category(){
        $lvalue=$_GET['id'];
        $this->load->model('query');
        echo $data=$this->query->fetch_cat($lvalue);
    }

    public function news(){
        $lvalue=$_GET['lid'];
        $uvalue=$_GET['uid'];
        $cvalue=$_GET['cid'];
        $this->load->model('query');
        $data=json_decode($this->query->fetch_news($lvalue,$uvalue,$cvalue));

        $object = array(array(
                        "n_id"=>"",
                        "u_id"=>"",
                        "headline"=>"",
                        "description"=>"",
                        "i_id"=>array(),
                        "url_i"=>array(),
                        "v_id"=>"",
                        "url"=>"",
                        "n_g_id"=>"",
                        "b_id"=>"")              
                        );
//print_r($object);
        $ar = (array)($data[0]);
        $base = $ar['n_id'];
        


$count=0;
$var = 0;
        foreach ($data as $i => $j ){            

          $v = (array)$data[$i];          

          if ( $var == 0 ){

            $object[$count]['n_id'] = $v['n_id'];
            $object[$count]['u_id'] = $v['u_id'];
            $object[$count]['headline'] = $v['headline'];
            $object[$count]['description'] = $v['description'];
            array_push($object[$count]['i_id'], $v['i_id']);
            array_push($object[$count]['url_i'], $v['url_i']);
            $object[$count]['v_id'] = $v['v_id'];
            $object[$count]['url'] = $v['url'];
            $object[$count]['n_g_id'] = $v['n_g_id'];
            $object[$count]['b_id'] = $v['b_id'];
            //print_r($object);
            //$count = 1;
            $var = 1 ;
//print_r($object);
          }
         else {
                if ( $v['n_id'] == $base ){

                array_push($object[$count]['i_id'], $v['i_id']);
                array_push($object[$count]['url_i'], $v['url_i']);
                
                 }

                 else{

                    $count = $count + 1;                    
                   
                    $object[$count]['n_id'] = $v['n_id'];
                     $object[$count]['u_id'] = $v['u_id'];
                     $object[$count]['headline'] = $v['headline'];
                     $object[$count]['description'] = $v['description'];
                     $object[$count]['i_id'][0]= $v['i_id'];
                     $object[$count]['url_i'][0]= $v['url_i'];
                     $object[$count]['v_id'] = $v['v_id'];
                     $object[$count]['url'] = $v['url'];
                     $object[$count]['n_g_id'] = $v['n_g_id'];
                     $object[$count]['b_id'] = $v['b_id'];
                    $base = $v['n_id'];
                    
                }
         }
          
      
  }

  echo json_encode($object);
        
    }

    public function user(){
        $uvalue=$_GET['uid'];
        $this->load->model('query');
        echo $data=$this->query->fetch_user($uvalue);
    }
}
?>