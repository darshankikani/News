-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 24, 2019 at 06:19 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookmark`
--

DROP TABLE IF EXISTS `bookmark`;
CREATE TABLE IF NOT EXISTS `bookmark` (
  `b_id` int(20) NOT NULL AUTO_INCREMENT,
  `u_id` int(20) NOT NULL,
  `n_g_id` int(20) NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookmark`
--

INSERT INTO `bookmark` (`b_id`, `u_id`, `n_g_id`) VALUES
(33, 12, 37),
(34, 12, 44),
(35, 1, 37),
(36, 2, 49);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `c_id` int(20) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `l_id` int(20) NOT NULL,
  `c_g_id` int(20) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`c_id`, `c_name`, `l_id`, `c_g_id`) VALUES
(1, 'Sports', 1, 1),
(2, ' खेल', 2, 1),
(3, 'રમતો', 3, 1),
(4, 'Crime', 1, 2),
(5, 'अपराध', 2, 2),
(6, 'અપરાધ', 3, 2),
(7, 'Entertainment', 1, 3),
(8, 'मनोरंजन', 2, 3),
(9, ' મનોરંજન', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
CREATE TABLE IF NOT EXISTS `comment` (
  `com_id` int(20) NOT NULL AUTO_INCREMENT,
  `n_g_id` int(20) NOT NULL,
  `text` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `u_id` int(20) NOT NULL,
  PRIMARY KEY (`com_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`com_id`, `n_g_id`, `text`, `u_id`) VALUES
(7, 37, 'fsvd', 1),
(8, 44, 'hj', 12),
(9, 37, 'ghh', 12),
(10, 37, 'hg', 12);

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
CREATE TABLE IF NOT EXISTS `image` (
  `i_id` int(11) NOT NULL AUTO_INCREMENT,
  `url_i` varchar(255) NOT NULL,
  `n_g_id` int(20) NOT NULL,
  PRIMARY KEY (`i_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`i_id`, `url_i`, `n_g_id`) VALUES
(24, 'E-Commerce-Web-Design-India.png', 37),
(25, 'MongoDB-CRUD-operations.jpg', 37),
(26, 'E-Commerce-Web-Design-India1.png', 39),
(27, 'IMG-20161122-WA0001.jpg', 39),
(28, 'MongoDB-CRUD-operations1.jpg', 39),
(29, 'E-Commerce-Web-Design-India2.png', 41),
(30, 'MongoDB-CRUD-operations2.jpg', 41),
(31, 'E-Commerce-Web-Design-India3.png', 42),
(32, 'E-Commerce-Web-Design-India4.png', 43),
(33, 'E-Commerce-Web-Design-India5.png', 44),
(34, 'IMG-20161122-WA00011.jpg', 44),
(35, 'MongoDB-CRUD-operations3.jpg', 44),
(36, 'E-Commerce-Web-Design-India6.png', 45),
(37, 'MongoDB-CRUD-operations4.jpg', 45),
(38, 'E-Commerce-Web-Design-India7.png', 46),
(39, 'E-Commerce-Web-Design-India8.png', 47),
(40, 'MongoDB-CRUD-operations5.jpg', 47),
(41, 'E-Commerce-Web-Design-India9.png', 48),
(42, 'IMG-20161122-WA00012.jpg', 48),
(43, 'MongoDB-CRUD-operations6.jpg', 48),
(44, 'b.jpg', 49),
(45, 'b1.jpg', 49),
(46, 'f.jpg', 49),
(47, 'f1.jpg', 49);

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
CREATE TABLE IF NOT EXISTS `language` (
  `l_id` int(20) NOT NULL AUTO_INCREMENT,
  `l_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`l_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`l_id`, `l_name`) VALUES
(1, 'english'),
(2, 'hindi'),
(3, 'gujarati');

-- --------------------------------------------------------

--
-- Table structure for table `newsd`
--

DROP TABLE IF EXISTS `newsd`;
CREATE TABLE IF NOT EXISTS `newsd` (
  `n_id` int(20) NOT NULL AUTO_INCREMENT,
  `l_id` int(20) NOT NULL,
  `u_id` int(20) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `headline` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(5) NOT NULL DEFAULT '0',
  `n_g_id` int(20) NOT NULL,
  `c_g_id` int(20) NOT NULL,
  PRIMARY KEY (`n_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsd`
--

INSERT INTO `newsd` (`n_id`, `l_id`, `u_id`, `latitude`, `longitude`, `headline`, `description`, `date`, `status`, `n_g_id`, `c_g_id`) VALUES
(41, 2, 1, 31.1976192, 72.8236032, 's', 'dsf', '2018-12-31 13:35:41', 1, 37, 1),
(43, 2, 12, 21.1935231, 72.8236032, 'scd', 'ds', '2018-12-31 13:43:51', 1, 43, 1),
(44, 3, 2, 21.1935231, 72.8236032, 'gfg', 'gd', '2018-12-31 13:47:49', 1, 44, 1),
(45, 1, 1, 21.1935231, 72.8236032, 'jhf', 'tyj', '2018-12-31 17:33:21', 1, 45, 1),
(46, 1, 1, 21.1938232, 72.8236032, 'xgfd', 'gnh', '2019-01-01 09:51:10', 1, 46, 1),
(47, 3, 1, 21.186969599999998, 72.8162304, 'asd', 'safd', '2019-01-02 11:06:44', 0, 47, 2),
(48, 2, 1, 21.1943424, 72.8080384, 'rq4', 'rwe', '2019-01-08 10:22:33', 0, 48, 1),
(49, 3, 1, 21.2033536, 72.83343359999999, 'hd', 'gdtrf', '2019-01-21 17:24:08', 1, 49, 2),
(50, 2, 1, 21.2033536, 72.83343359999999, 'gxdv', 'xgdf', '2019-01-21 17:26:15', 1, 49, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `u_id` int(20) NOT NULL AUTO_INCREMENT,
  `u_name` varchar(20) NOT NULL,
  `mo_no` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`u_id`, `u_name`, `mo_no`, `email`, `password`) VALUES
(1, 'abc', '9723262080', 'abc@xyz.com', '123'),
(2, 'xyz', '9856234578', 'xyz@admin.com', '1234'),
(12, 'absd', '8956421375', 'abc@pro.com', '1245');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
CREATE TABLE IF NOT EXISTS `video` (
  `v_id` int(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `n_g_id` int(20) NOT NULL,
  `you_url` varchar(255) NOT NULL,
  PRIMARY KEY (`v_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`v_id`, `url`, `n_g_id`, `you_url`) VALUES
(7, 'php.mp4', 37, ''),
(8, 'php1.mp4', 39, ''),
(9, 'videoplayback.3gpp', 44, ''),
(10, 'php2.mp4', 45, ''),
(11, 'php3.mp4', 46, ''),
(12, 'php4.mp4', 47, ''),
(13, 'php5.mp4', 48, ''),
(14, 'Introducing_Yourself_-_How_to_Introduce_Yourself_In_English.mp4', 49, '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
